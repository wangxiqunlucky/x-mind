<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title> 登录 </title>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/default.css') }}" />
</head>

<body class="loginWeb">
    <div class="loginBox">
        <div class="innerBox">
            <div class="logo"> <img src="{{ asset('images/logo.png') }}" /></div>
            <form id="login_form" action="{{route('signin')}}" method="post">
                <div class="loginInfo">
                    <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                    <ul>
                        <li class="row1">登录邮箱：</li>
                        <li class="row2"><input class="input" name="admin[email]" id="email" size="30" type="text" /></li>
                    </ul>
                    <ul>
                        <li class="row1">登录密码：</li>
                        <li class="row2"><input class="input" name="admin[password]" id="pwd" size="30" type="password" /></li>
                    </ul>
                    <!--<ul>
                        <li class="row1">验证码：</li>
                        <li class="row2"><input class="input" id="verify_code" name="verify_code" type="text" style="width:80px;" />&nbsp;&nbsp;&nbsp;<img src="{:U('Public/verifyCode')}"  title="看不清？单击此处刷新" onClick="this.src+='?rand='+Math.random();"  style="cursor: pointer; vertical-align: middle;"/></li>
                    </ul>-->
<!--                    <ul>
                        <li class="row1">手机验证：</li>
						<li class="row2"><input class="input" size="6" id="verify_code" name="verify_code" type="text" style="width:60px;" />&nbsp;&nbsp;&nbsp;<input type="button" value="获取验证码" id="send_verify_code" class="btn" style="background-color: #CCCCCC; border:none; color: #000099;" /></li>
                        <li class="row2"><input class="input" id="verify_code" name="verify_code" type="text" style="width:80px;" />&nbsp;&nbsp;&nbsp;<img src="{:U('Public/verifyCode')}"  title="看不清？单击此处刷新" onClick="this.src+='?rand='+Math.random();"  style="cursor: pointer; vertical-align: middle;"/></li>
                    </ul>-->
                </div>
            <div class="clear"></div>
            <div class="operation"><button type="submit">登录</button></div>
			<div style="text-align:center">Copyright(©) 2014 广州君海网络科技有限公司 版权所有</div>
            </form>
        </div>
    </div>

    <include file="Common/javascripts" />
    <script type="text/javascript">
	
        $(function(){
            // 登录
            $(".submit").click(function(){
                if($("#email").val() == '' || $("#pwd").val() == '' || $("#verify_code").val() == ''){
					if($("#email").val() == ''){
						popup.alert("请输入登录邮箱！");
					}
					if($("#pwd").val() == ''){
						popup.alert("请输入登录密码！");
					}
					if($("#verify_code").val() == ''){
						popup.alert("请输入手机验证码！");
					}
                    return false;
                }
                commonAjaxSubmit("{:U('Public/login')}");
            });

            // 找回密码
            $(".findPwd").click(function() {
                if($("#email").val() == ''){
                    popup.alert("请填需要找回密码的登录邮箱！");
                    return false;
                }
                commonAjaxSubmit("{:U('Public/sendFindPwdMail')}");
            });
			
/*			$(".submit").click(function(){
                if($("#email").val() == '' || $("#pwd").val() == ''){
                    popup.alert("请填写完整的表单后进行登录！");
                    return false;
                }
                commonAjaxSubmit("{:U('Public/login')}");
            });*/
			
			$("#send_verify_code").click(function(){
				if($("#email").val() == ''){
                    popup.alert("请填写登录邮箱！");
                    return false;
                }
				
				$("form").ajaxSubmit({
					url:"{:U('Public/sendVerifyCode')}",
					type:"POST",
					success:function(data, st) {
						if(data.status==1){
							popup.success(data.info);
							setTimeout(function(){
								popup.close("asyncbox_success");
							},1000);					
							
							document.getElementById('verify_code').focus();
							var obj = document.getElementById('send_verify_code');
							time(obj, 60);
						}else{
							popup.error(data.info);
							setTimeout(function(){
								popup.close("asyncbox_error");
							},2000);
						}
					}
				});
            });
        });
		
		
		function time(o, wait) {
			if (wait == 0) {
				o.removeAttribute("disabled");   
				o.value="重新获取验证码";
				wait = 60;
			} else {				
				o.setAttribute("disabled", true);
				o.value="重新获取(" + wait + "秒后)";
				wait--;
				setTimeout(function() {
					time(o, wait)
				},1000)
			}
		}
    </script>
</body>
</html>
