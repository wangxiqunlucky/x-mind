<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Routing\Controller as BaseController;

class CommonController extends BaseController{
    public function __construct() {
        if (! Auth::viaRemember()) {
            return redirect('public/login_page');
        }
    }
}