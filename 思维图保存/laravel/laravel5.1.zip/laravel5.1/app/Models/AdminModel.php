<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminModel extends Model{
    protected $table = 'think_admin';//指定数据表,否则将以类名+s作为数据表名
    public $timestamps = false;//关闭自动更新字段created_at和updated_at功能
}
