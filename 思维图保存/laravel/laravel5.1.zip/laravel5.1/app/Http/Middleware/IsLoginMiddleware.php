<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class IsLoginMiddleware {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        //判断当前访问的是否为公共控制器,是则继续执行
        $path_dir = explode('/',$request->path());
        if( $path_dir[0]== 'public') {
            return $next($request);
        }
        //访问其他控制器则验证是否登录
        if (! Auth::check()) {
            var_dump(Auth::check());
            return redirect()->route('login_page');
        }        
        return $next($request);
    }

}
