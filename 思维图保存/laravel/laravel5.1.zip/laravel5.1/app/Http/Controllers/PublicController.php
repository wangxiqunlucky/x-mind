<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\CommonController;
use DB;
use Auth;

//use App\Models\AdminModel as Admin;
//use App\Http\Controllers\IndexController;
//use Illuminate\Http\RedirectResponse;

class PublicController extends CommonController {

//    public function __construct() {
    //手册上下述的打印函数内的方法不可以使用.
//        var_dump(Auth::viaRemember());exit;
    //验证是否存在合法cookie,存在则跳转到首页
//        if (Auth::check()) {
//            return redirect()->route('index');
//        }
//    }

    public function login_page() {
        if (Auth::check()) {
            return redirect()->route('index');
        }
        return view('login_page');
    }

    public function signin(Request $request) {
        if (Auth::check()) {
            return redirect()->route('index');
        }
        //获取Request的输入
        $input_arr = $request->input('admin');
//        var_dump($input_arr);exit;
        //如果传入的是数组,则通过点号获取单元具体的值
        /*
          $email = $request->input('admin.email');
          var_dump($email);
         */
        /*
         * 使用DB来进行数据查询
          $users = DB::select('select * from think_admin where email= :email',['email'=>$input_arr['email']]);
          var_dump($users);
         */
        /*
         * 使用ORM来进行数据查询
         *  Admin::where('email',$input_arr['email'])->where('password',md5('nimdaae' . md5($input_arr['password'])))->first()->toArray();
         */
        /*        $admin_arr = Admin::where('email', $input_arr['email'])->where('password', md5('nimdaae' . md5($input_arr['password'])))->first()->toArray();
          if (! isset($admin_arr)) {
          //echo json_encode([0, '邮箱或密码错误.']);
          echo 'failed';
          exit;
          }
         *
         */
        //设置cookie
        $remember = true;
//        var_dump(Auth::attempt(['email' => $input_arr['email'], 'password' => $input_arr['password']], $remember));exit;
        if (Auth::attempt(['email' => $input_arr['email'], 'password' => $input_arr['password']], $remember)) {
            // 这个用户被记住了...
            return redirect()->intended('index/index');
        }
    }

}
