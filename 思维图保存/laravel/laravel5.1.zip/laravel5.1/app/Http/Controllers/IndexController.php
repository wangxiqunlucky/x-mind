<?php
namespace App\Http\Controllers;

use App\Http\Controllers\CommonController;

class IndexController extends CommonController{
    public function __construct() {
        parent::__construct();
    }
    public function index(){
        echo '登录成功!';
    }
}